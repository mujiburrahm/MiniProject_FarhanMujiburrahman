<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pegawai</title>
    <style>
        body {
            font-family: sans-serif;
            margin: 20px;
            background-color: #f8f9fa;
            color: #343a40;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }
        .btn {
            padding: 8px 15px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 14px;
            margin-right: 5px;
            border: none;
            cursor: pointer;
        }
        .btn-primary {
            background-color: #007bff;
            color: white;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .btn-info {
            background-color: #17a2b8;
            color: white;
        }
        .btn-info:hover {
            background-color: #117a8b;
        }
        .btn-warning {
            background-color: #ffc107;
            color: #212529;
        }
        .btn-warning:hover {
            background-color: #d39e00;
        }
        .btn-danger {
            background-color: #dc3545;
            color: white;
        }
        .btn-danger:hover {
            background-color: #bd2130;
        }
        .table-container {
            overflow-x: auto; /* Agar tabel bisa di-scroll horizontal jika terlalu lebar */
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            font-size: 15px;
        }
        th, td {
            border: 1px solid #dee2e6;
            padding: 12px;
            text-align: left;
            vertical-align: middle;
        }
        th {
            background-color: #e9ecef;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            padding: 15px;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        .profile-thumbnail {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 50%; /* Lingkaran */
            border: 2px solid #ddd;
        }
        .no-thumbnail {
            display: inline-block;
            width: 50px;
            height: 50px;
            line-height: 50px;
            text-align: center;
            background-color: #e9ecef;
            color: #6c757d;
            border-radius: 50%;
            font-size: 11px;
            font-weight: bold;
        }
        .pagination-container {
            margin-top: 20px;
            display: flex;
            justify-content: center;
        }
        .action-buttons form {
            display: inline-block; /* Agar tombol hapus sejajar */
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Daftar Pegawai</h1>

        @if (session('success'))
            <div class="alert-success">
                {{ session('success') }}
            </div>
        @endif

        <a href="{{ route('pegawai.create') }}" class="btn btn-primary" style="margin-bottom: 20px;">Tambah Pegawai Baru</a>

        @if ($pegawais->count())
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Foto</th>
                            <th>Nama Lengkap</th>
                            <th>NIP</th>
                            <th>Jabatan</th>
                            <th>Departemen</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($pegawais as $pegawai)
                            <tr>
                                <td>
                                    @if ($pegawai->foto_profil)
                                        <img src="{{ asset('storage/' . $pegawai->foto_profil) }}" alt="Foto {{ $pegawai->nama_lengkap }}" class="profile-thumbnail">
                                    @else
                                        <span class="no-thumbnail">No Pic</span>
                                    @endif
                                </td>
                                <td>{{ $pegawai->nama_lengkap }}</td>
                                <td>{{ $pegawai->nip ?: '-' }}</td>
                                <td>{{ $pegawai->jabatan ?: '-' }}</td>
                                <td>{{ $pegawai->departemen ?: '-' }}</td>
                                <td class="action-buttons">
                                    <a href="{{ route('pegawai.show', $pegawai->id) }}" class="btn btn-info">Lihat</a>
                                    <a href="{{ route('pegawai.edit', $pegawai->id) }}" class="btn btn-warning">Edit</a>
                                    <form action="{{ route('pegawai.destroy', $pegawai->id) }}" method="POST">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger" onclick="return confirm('Anda yakin ingin menghapus data pegawai {{ $pegawai->nama_lengkap }}?')">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            @if ($pegawais->hasPages())
            <div class="pagination-container">
                {{ $pegawais->links() }} {{-- Menampilkan link pagination --}}
            </div>
            @endif

        @else
            <p style="text-align:center; margin-top: 20px;">Belum ada data pegawai.</p>
        @endif
    </div>
</body>
</html>