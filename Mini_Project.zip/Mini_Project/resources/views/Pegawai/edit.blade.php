<!DOCTYPE html>
<html>
<head>
    <title>Edit Pegawai: {{ $pegawai->nama_lengkap }}</title>
</head>
<body>
    <h1>Edit Pegawai: {{ $pegawai->nama_lengkap }}</h1>

    @if ($errors->any())
        <div style="color: red;">
            <strong>Whoops! Ada kesalahan input:</strong>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('pegawai.update', $pegawai->id) }}" method="POST" enctype="multipart/form-data">
        @csrf <!-- Token CSRF -->
        @method('PUT') <!-- Method spoofing untuk HTTP PUT -->

        <div>
            <label for="nama_lengkap">Nama Lengkap:</label>
            <input type="text" id="nama_lengkap" name="nama_lengkap" value="{{ old('nama_lengkap', $pegawai->nama_lengkap) }}" required>
        </div>

        <div>
            <label for="nip">NIP:</label>
            <input type="text" id="nip" name="nip" value="{{ old('nip', $pegawai->nip) }}">
        </div>

        <div>
            <label for="jabatan">Jabatan:</label>
            <input type="text" id="jabatan" name="jabatan" value="{{ old('jabatan', $pegawai->jabatan) }}">
        </div>

        <div>
            <label for="departemen">Departemen:</label>
            <input type="text" id="departemen" name="departemen" value="{{ old('departemen', $pegawai->departemen) }}">
        </div>

        <div>
            <label for="alamat">Alamat:</label>
            <textarea id="alamat" name="alamat">{{ old('alamat', $pegawai->alamat) }}</textarea>
        </div>

        <div>
            <label for="nomor_telepon">Nomor Telepon:</label>
            <input type="text" id="nomor_telepon" name="nomor_telepon" value="{{ old('nomor_telepon', $pegawai->nomor_telepon) }}">
        </div>

        <div>
            <label for="tanggal_masuk">Tanggal Masuk:</label>
            <input type="date" id="tanggal_masuk" name="tanggal_masuk" value="{{ old('tanggal_masuk', $pegawai->tanggal_masuk) }}">
        </div>

        <div>
            <label for="foto_profil">Path Foto Profil (opsional):</label>
            <input type="file" id="foto_profil" name="foto_profil" value="{{ old('foto_profil', $pegawai->foto_profil) }}" enctype="multipart/form-data">
            
            <!-- Jika Anda mengelola upload:
            @if ($pegawai->foto_profil)
                <p>Foto saat ini: <img src="{{ asset('storage/' . $pegawai->foto_profil) }}" alt="Foto Profil" width="100"></p>
            @endif
            <input type="file" name="foto_profil_baru">
            -->
        </div>

        <div>
            <button type="submit">Update Pegawai</button>
        </div>
    </form>

    <a href="{{ route('pegawai.index') }}">Kembali ke Daftar Pegawai</a>
</body>
</html>