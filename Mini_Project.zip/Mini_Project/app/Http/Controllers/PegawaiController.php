<?php

namespace App\Http\Controllers;

use App\Models\Pegawai; // Pastikan namespace model Anda benar
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage; // Untuk mengelola file

class PegawaiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $pegawais = Pegawai::latest()->paginate(10); // Ambil data terbaru, 10 per halaman
        return view('pegawai.index', compact('pegawais'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('pegawai.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'nama_lengkap' => 'required|string|max:255',
            'nip' => 'nullable|string|max:50|unique:pegawais,nip', // 'pegawais' adalah nama tabel
            'jabatan' => 'nullable|string|max:100',
            'departemen' => 'nullable|string|max:100',
            'alamat' => 'nullable|string',
            'nomor_telepon' => 'nullable|string|max:20',
            'tanggal_masuk' => 'nullable|date',
            'foto_profil' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048', // Validasi untuk file gambar
        ]);

        // Handle File Upload
        if ($request->hasFile('foto_profil')) {
            // Simpan file ke 'storage/app/public/profils'
            // dan $path akan berisi path relatif seperti 'profils/namafileunik.jpg'
            $path = $request->file('foto_profil')->store('profils', 'public');
            $validatedData['foto_profil'] = $path; // Simpan path ke database
        }

        Pegawai::create($validatedData);

        return redirect()->route('pegawai.index')
                         ->with('success', 'Pegawai baru berhasil ditambahkan.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Pegawai  $pegawai
     * @return \Illuminate\Http\Response
     */
    public function show(Pegawai $pegawai) // Menggunakan Route Model Binding
    {
        return view('pegawai.show', compact('pegawai'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Pegawai  $pegawai
     * @return \Illuminate\Http\Response
     */
    public function edit(Pegawai $pegawai)
    {
        return view('pegawai.edit', compact('pegawai'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Pegawai  $pegawai
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Pegawai $pegawai)
    {
        $validatedData = $request->validate([
            'nama_lengkap' => 'required|string|max:255',
            // NIP unik, tapi abaikan NIP pegawai yang sedang diedit (gunakan ID pegawai saat ini)
            'nip' => 'nullable|string|max:50|unique:pegawais,nip,' . $pegawai->id,
            'jabatan' => 'nullable|string|max:100',
            'departemen' => 'nullable|string|max:100',
            'alamat' => 'nullable|string',
            'nomor_telepon' => 'nullable|string|max:20',
            'tanggal_masuk' => 'nullable|date',
            'foto_profil' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048', // Validasi untuk file gambar
        ]);

        // Handle File Upload jika ada file baru
        if ($request->hasFile('foto_profil')) {
            // 1. Hapus foto lama jika ada
            if ($pegawai->foto_profil) {
                Storage::disk('public')->delete($pegawai->foto_profil);
            }

            // 2. Upload foto baru
            $path = $request->file('foto_profil')->store('profils', 'public');
            $validatedData['foto_profil'] = $path; // Simpan path baru ke database
        }
        // Jika tidak ada file baru yang diupload, $validatedData['foto_profil'] tidak akan di-set
        // dan kolom foto_profil di database tidak akan diubah oleh $pegawai->update($validatedData)
        // jika 'foto_profil' tidak ada di $validatedData.

        $pegawai->update($validatedData);

        return redirect()->route('pegawai.index')
                         ->with('success', 'Data pegawai berhasil diperbarui.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Pegawai  $pegawai
     * @return \Illuminate\Http\Response
     */
    public function destroy(Pegawai $pegawai)
    {
        // Hapus foto profil dari storage jika ada sebelum menghapus data pegawai
        if ($pegawai->foto_profil) {
            Storage::disk('public')->delete($pegawai->foto_profil);
        }

        $pegawai->delete();

        return redirect()->route('pegawai.index')
                         ->with('success', 'Data pegawai berhasil dihapus.');
    }
}