<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pegawai extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'nama_lengkap',
        'nip',
        'jabatan',
        'departemen',
        'alamat',
        'nomor_telepon',
        'tanggal_masuk',
        'foto_profil', // Jika Anda menyimpan path foto di database
    ];

    /**
     * The table associated with the model.
     *
     * @var string
     */
    // protected $table = 'pegawais'; // Laravel akan otomatis menggunakan 'pegawais' jika nama model 'Pegawai'

    /**
     * The primary key associated with the table.
     *
     * @var string
     */
    // protected $primaryKey = 'id';

    /**
     * Indicates if the model's ID is auto-incrementing.
     *
     * @var bool
     */
    // public $incrementing = true;

    /**
     * Indicates if the model should be timestamped.
     *
     * @var bool
     */
    // public $timestamps = true; // Defaultnya true, (created_at, updated_at)
}