<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pegawai Baru</title>
    <style>
        body {
            font-family: sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        .form-group input[type="text"],
        .form-group input[type="date"],
        .form-group input[type="file"],
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box; /* Agar padding tidak menambah lebar total */
        }
        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }
        .btn {
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            padding: 10px;
            border: 1px solid #f5c6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        .alert-danger ul {
            margin: 0;
            padding-left: 20px;
        }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #007bff;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Tambah Pegawai Baru</h1>

        <?php if($errors->any()): ?>
            <div class="alert-danger">
                <strong>Whoops! Ada beberapa masalah dengan input Anda:</strong>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('pegawai.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?> <!-- Token CSRF untuk keamanan -->

            <div class="form-group">
                <label for="nama_lengkap">Nama Lengkap:</label>
                <input type="text" id="nama_lengkap" name="nama_lengkap" value="<?php echo e(old('nama_lengkap')); ?>" required>
            </div>

            <div class="form-group">
                <label for="nip">NIP:</label>
                <input type="text" id="nip" name="nip" value="<?php echo e(old('nip')); ?>">
            </div>

            <div class="form-group">
                <label for="jabatan">Jabatan:</label>
                <input type="text" id="jabatan" name="jabatan" value="<?php echo e(old('jabatan')); ?>">
            </div>

            <div class="form-group">
                <label for="departemen">Departemen:</label>
                <input type="text" id="departemen" name="departemen" value="<?php echo e(old('departemen')); ?>">
            </div>

            <div class="form-group">
                <label for="alamat">Alamat:</label>
                <textarea id="alamat" name="alamat"><?php echo e(old('alamat')); ?></textarea>
            </div>

            <div class="form-group">
                <label for="nomor_telepon">Nomor Telepon:</label>
                <input type="text" id="nomor_telepon" name="nomor_telepon" value="<?php echo e(old('nomor_telepon')); ?>">
            </div>

            <div class="form-group">
                <label for="tanggal_masuk">Tanggal Masuk:</label>
                <input type="date" id="tanggal_masuk" name="tanggal_masuk" value="<?php echo e(old('tanggal_masuk')); ?>">
            </div>

            <div class="form-group">
                <label for="foto_profil">Foto Profil (Opsional):</label>
                <input type="file" id="foto_profil" name="foto_profil">
                
            </div>

            <div>
                <button type="submit" class="btn">Simpan Pegawai</button>
            </div>
        </form>

        <a href="<?php echo e(route('pegawai.index')); ?>" class="back-link">Kembali ke Daftar Pegawai</a>
    </div>
</body>
</html><?php /**PATH D:\laragon\www\blogku\resources\views/pegawai/create.blade.php ENDPATH**/ ?>