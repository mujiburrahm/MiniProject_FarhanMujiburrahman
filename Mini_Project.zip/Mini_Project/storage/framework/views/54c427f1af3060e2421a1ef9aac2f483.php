<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Pegawai: <?php echo e($pegawai->nama_lengkap); ?></title>
    <style>
        body {
            font-family: sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
            color: #333;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            max-width: 700px;
            margin: 20px auto;
        }
        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 25px;
            border-bottom: 2px solid #eee;
            padding-bottom: 10px;
        }
        .detail-item {
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #f0f0f0;
        }
        .detail-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }
        .detail-item strong {
            display: inline-block;
            width: 150px; /* Lebar label */
            color: #555;
        }
        .profile-image-container {
            text-align: center;
            margin-bottom: 20px;
        }
        .profile-image {
            max-width: 200px;
            max-height: 200px;
            border-radius: 50%; /* Membuat gambar jadi lingkaran */
            border: 3px solid #ddd;
            padding: 5px;
            background-color: #fff;
            object-fit: cover; /* Memastikan gambar terisi tanpa distorsi */
            width: 200px; /* Set agar konsisten jika gambar kecil */
            height: 200px; /* Set agar konsisten jika gambar kecil */
        }
        .no-image {
            display: inline-block;
            width: 200px;
            height: 200px;
            line-height: 200px;
            text-align: center;
            background-color: #e9ecef;
            color: #6c757d;
            border-radius: 50%;
            font-size: 16px;
        }
        .actions {
            margin-top: 30px;
            text-align: center;
        }
        .actions a, .actions button {
            display: inline-block;
            padding: 10px 20px;
            margin: 5px;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
        }
        .btn-primary {
            background-color: #007bff;
            color: white;
            border: none;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .btn-secondary {
            background-color: #6c757d;
            color: white;
            border: none;
        }
        .btn-secondary:hover {
            background-color: #545b62;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Detail Pegawai</h1>

        <div class="profile-image-container">
            <?php if($pegawai->foto_profil): ?>
                <img src="<?php echo e(asset('storage/' . $pegawai->foto_profil)); ?>" alt="Foto Profil <?php echo e($pegawai->nama_lengkap); ?>" class="profile-image">
            <?php else: ?>
                <div class="no-image">Tidak Ada Foto</div>
            <?php endif; ?>
        </div>

        <div class="detail-item">
            <strong>Nama Lengkap:</strong> <?php echo e($pegawai->nama_lengkap); ?>

        </div>
        <div class="detail-item">
            <strong>NIP:</strong> <?php echo e($pegawai->nip ?: '-'); ?>

        </div>
        <div class="detail-item">
            <strong>Jabatan:</strong> <?php echo e($pegawai->jabatan ?: '-'); ?>

        </div>
        <div class="detail-item">
            <strong>Departemen:</strong> <?php echo e($pegawai->departemen ?: '-'); ?>

        </div>
        <div class="detail-item">
            <strong>Alamat:</strong> <?php echo e($pegawai->alamat ?: '-'); ?>

        </div>
        <div class="detail-item">
            <strong>Nomor Telepon:</strong> <?php echo e($pegawai->nomor_telepon ?: '-'); ?>

        </div>
        <div class="detail-item">
            <strong>Tanggal Masuk:</strong> <?php echo e($pegawai->tanggal_masuk ? \Carbon\Carbon::parse($pegawai->tanggal_masuk)->isoFormat('D MMMM YYYY') : '-'); ?>

        </div>
        <div class="detail-item">
            <strong>Dibuat pada:</strong> <?php echo e($pegawai->created_at->isoFormat('D MMMM YYYY, HH:mm:ss')); ?>

        </div>
        <div class="detail-item">
            <strong>Diperbarui pada:</strong> <?php echo e($pegawai->updated_at->isoFormat('D MMMM YYYY, HH:mm:ss')); ?>

        </div>

        <div class="actions">
            <a href="<?php echo e(route('pegawai.edit', $pegawai->id)); ?>" class="btn-primary">Edit Pegawai Ini</a>
            <a href="<?php echo e(route('pegawai.index')); ?>" class="btn-secondary">Kembali ke Daftar</a>
        </div>
    </div>
</body>
</html><?php /**PATH D:\laragon\www\blogku\resources\views/pegawai/show.blade.php ENDPATH**/ ?>