<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Pegawai; // Panggil model Pegawai

class PegawaiSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Hapus data lama jika ada (opsional, tapi berguna agar data tidak duplikat jika seeder dijalankan berkali-kali)
        // Pegawai::truncate(); // Hati-hati jika ada foreign key constraint

        // Membuat 20 data pegawai dummy menggunakan factory
        Pegawai::factory()->count(20)->create();

        // Anda juga bisa membuat satu data spesifik jika diperlukan
        // Pegawai::factory()->create([
        //     'nama_lengkap' => 'John Doe (Contoh)',
        //     'nip' => '1234567890',
        //     'jabatan' => 'Developer',
        //     // ... field lainnya
        // ]);
    }
}