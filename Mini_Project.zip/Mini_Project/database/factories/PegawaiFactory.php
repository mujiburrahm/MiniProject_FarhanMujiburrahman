<?php

namespace Database\Factories;

use App\Models\Pegawai; // Pastikan namespace model benar
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str; // Jika Anda ingin menggunakan Str helper

class PegawaiFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Pegawai::class; // Atau bisa juga App\Models\Pegawai::class

    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'nama_lengkap' => $this->faker->name(), // Faker untuk nama
            'nip' => $this->faker->unique()->numerify('##########'), // NIP unik 10 digit angka
            'jabatan' => $this->faker->randomElement(['Staff', 'Supervisor', 'Manager', 'Analis', 'Teknisi']),
            'departemen' => $this->faker->randomElement(['IT', 'HRD', 'Keuangan', 'Marketing', 'Operasional']),
            'alamat' => $this->faker->address(), // Faker untuk alamat
            'nomor_telepon' => $this->faker->phoneNumber(), // Faker untuk nomor telepon
            'tanggal_masuk' => $this->faker->dateTimeBetween('-5 years', 'now')->format('Y-m-d'), // Tanggal masuk antara 5 tahun lalu sampai sekarang
            'foto_profil' => null, // Biarkan null dulu, atau Anda bisa set path ke foto placeholder jika ada
                                    // Misalnya: 'profils/placeholder.jpg' jika Anda punya file tersebut di storage/app/public/profils
            'created_at' => now(),
            'updated_at' => now(),
        ];
    }
}