<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PegawaiController;

Route::get('/', [PegawaiController::class, 'index'])->name('dashboard'); // Atau dashboard.index jika Anda punya DashboardController

// Ini sudah mencakup SEMUA rute CRUD untuk pegawai
Route::resource('pegawai', PegawaiController::class);

// Tidak perlu ada lagi definisi rute pegawai di bawah ini